myMixedTypeList = [21,82,80.02,False,"My favourite color is Black","70"]
for item in myMixedTypeList:
    print("{} is of the data type {}".format(item,type(item)))
