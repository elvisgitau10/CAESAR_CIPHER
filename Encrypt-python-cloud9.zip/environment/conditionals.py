userReply = input("What emoji key holder would you like? (Enter shitface,lovehearts or sidekiss)")
if userReply == "shitface":
   print("Here are the number of shitfaces that are available")
elif userReply == "lovehearts":
    print("Here are the number of lovehearts that are available")
elif userReply == "sidekiss":
    sidekiss = input("How many sidekisses would you like? (Enter a number)")
    print("Here are {} sidekisses.".format(sidekiss))
else:
    print("Thank you, please come again.")